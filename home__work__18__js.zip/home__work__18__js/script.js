
let but =document.querySelector("#cl");
but.addEventListener("click",myMove);
function myMove() {
    but.style.display="none"
    let elem= document.getElementById("animate");
    let pos=0;
    let id= setInterval(frame,10);
    function frame() {
        if (pos==350) {
            clearInterval(id)
             but.style.display="block"
        }else{
             pos++
          elem.style.top= pos + "px";
    elem.style.left= pos +"px"
        }
       
    }
}